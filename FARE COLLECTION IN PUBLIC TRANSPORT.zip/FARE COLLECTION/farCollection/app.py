from flask import Flask, request, render_template, url_for
import mysql.connector

app = Flask(__name__)

# MySQL database configuration
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="fare_collection_db"
)
cursor = db.cursor()

# Fetch ticket prices and available seats from the database
cursor.execute("SELECT route, price, available_seats FROM ticket_data")
ticket_data = {row[0]: {"price": row[1], "available_seats": row[2]} for row in cursor.fetchall()}


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict_price', methods=['POST'])
def predict_price():
    source = request.form['source']
    destination = request.form['destination']
    key = source + " to " + destination

    if key in ticket_data:
        amount = ticket_data[key]["price"]  # Use ticket_data instead of ticket_prices
        return render_template('payment.html', source=source, destination=destination, amount=amount)
    else:
        return "Sorry, no price available for the selected route."


from flask import url_for, redirect

@app.route('/book_ticket', methods=['POST'])
def book_ticket():
    source = request.form['source']
    destination = request.form['destination']
    passengers = int(request.form['passengers'])
    date = request.form['date']

    key = source + " to " + destination

    if key in ticket_data:
        available_seats = ticket_data[key]["available_seats"]
        if available_seats >= passengers:
            updated_seats = available_seats - passengers

            # Update available seats in the database
            cursor.execute("UPDATE ticket_data SET available_seats = %s WHERE route = %s", (updated_seats, key))
            db.commit()

            # Insert ticket details into the database
            cursor.execute("INSERT INTO tickets (source, destination, price, date, available_seats) VALUES (%s, %s, %s, %s, %s)", (source, destination, passengers * ticket_data[key]["price"], date, updated_seats))
            db.commit()

            # Retrieve the ID of the inserted ticket
            ticket_id = cursor.lastrowid

            # Render template after booking confirmed and redirect to print_ticket page
            return redirect(url_for('print_ticket', ticket_id=ticket_id))

        else:
            return "Sorry, not enough seats available for the selected route on the chosen date."
    else:
        return "Sorry, No Seat available for the selected route."

@app.route('/payment_complete', methods=['POST'])
def payment_complete():
    return "Payment Successful! Your ticket has been booked."

# from flask import render_template
@app.route('/print_ticket/<int:ticket_id>')
def print_ticket(ticket_id):
    # Retrieve booked ticket details from the database
    cursor.execute("SELECT * FROM tickets WHERE id = %s", (ticket_id,))
    ticket = cursor.fetchone()
    if ticket:
        ticket_details = {
            "ticket_id": ticket[0],
            "source": ticket[1],
            "destination": ticket[2],
            "price": ticket[3],
            "available_seats": ticket[4],
            "date": ticket[5]
        }
        return render_template('ticket.html', ticket_details=ticket_details)
    else:
        return f"Ticket with ID {ticket_id} not found."



if __name__ == '__main__':
    app.run(debug=True)
