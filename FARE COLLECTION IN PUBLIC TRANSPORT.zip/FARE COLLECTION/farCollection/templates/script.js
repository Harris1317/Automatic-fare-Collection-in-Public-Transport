// Define a dictionary to store ticket amounts based on from-to combinations
var ticketPrices = {
    "ERODE to ERODE": 0,   // Example: Replace "A to B" with your actual locations
    "ERODE to THINDAL": 15,
    "ERODE to PERUNDURAI": 25, 
    "ERODE to TOLL GATE": 30,
    "ERODE to PERUMANALLUR": 50,  
    "ERODE to AVINASHI": 60,
    "ERODE to THINDAL": 70, 
    "ERODE to COIMBATORE": 85,  
    "COIMBATORE to ERODE": 85,   
    "COIMBATORE to THINDAL": 70,
    "COIMBATORE to PERUNDURAI":60 , 
    "COIMBATORE to TOLL GATE": 55,
    "COIMBATORE to PERUMANALLUR": 35,  
    "COIMBATORE to AVINASHI": 25,
    "COIMBATORE to THINDAL": 70, 
    "COIMBATORE to COIMBATORE": 0, 
    "THINDAL to PERUNDURAI": 10, 
    "PERUNDURAI to THINDAL": 10,
    "PERUNDURAI to TOLL GATE-1": 5,
    "TOLL GATE-1 to PERUNDURAI": 5,
    "TOLL GATE-1 to PERUMANALLUR": 20,
    "PERUMANALLUR to TOLL GATE-1": 20,
    "PERUMANALLUR to AVINASHI": 10,
    "AVINASHI to PERUMANALLUR": 10,
    "AVINASHI to TOLL GATE-2": 10,
    "TOLL GATE-2 to AVINASHI": 10,
    "TOLL GATE-2 to COIMBATORE": 15,
    "COIMBATORE to TOLL GATE-2": 15,




    // Add more entries as needed
};

// Function to predict and display the ticket amount
function predictPrice() {
    var sourceInput = document.getElementById("source").value;
    var destinationInput = document.getElementById("destination").value;
    var key = sourceInput + " to " + destinationInput;

    var priceDiv = document.getElementById("price");

    if (ticketPrices.hasOwnProperty(key)) {
        var amount = ticketPrices[key];
        priceDiv.innerHTML = "Estimated Price: $" + amount;
    } else {
        priceDiv.innerHTML = "Sorry, no price available for the selected route.";
    }
}

function available_seat() {
    document.getElementById("Ava_seat").defaultValue = "30"
    var sourceInput = document.getElementById("source").value;
    var destinationInput = document.getElementById("destination").value;
    var key = sourceInput + " to " + destinationInput;
    document.getElementById("Ava_seat").defaultValue = "30"
    var seatInput = document.getElementById("Ava_seat").value;
    var passengersInput = document.getElementById("passengers").value;

    var priceDiv = document.getElementById("price");

    if (ticketPrices.hasOwnProperty(key)) {
        var seat =seatInput ;
        var totalseat = seatInput - passengersInput;
        document.getElementById("Ava_seat").defaultValue=totalseat
    } else {
        document.getElementById("Ava_seat").defaultValue = "Sorry, No Seat available for the selected route.";
    }
}

function togglePaymentOptions() {
    var paymentOptions = document.getElementById("payment-options");
    if (paymentOptions.style.display === "none") {
        paymentOptions.style.display = "block";
    } else {
        paymentOptions.style.display = "none";
    }
}
// Function to handle the ticket buying process
function buyTicket() {
    var sourceDetailsSpan = document.getElementById("source-details");
    var destinationDetailsSpan = document.getElementById("destination-details");
    var dateDetailsSpan = document.getElementById("date-details");
    var passengersDetailsSpan = document.getElementById("passengers-details");
    var priceDetailsSpan = document.getElementById("price-details");

    var sourceInput = document.getElementById("source").value;
    var destinationInput = document.getElementById("destination").value;
    var dateInput = document.getElementById("date").value;
    var passengersInput = document.getElementById("passengers").value;

    var key = sourceInput + " to " + destinationInput;

    if (ticketPrices.hasOwnProperty(key)) {
        var amount = ticketPrices[key];
        var totalAmount = amount * passengersInput;

        sourceDetailsSpan.innerText = sourceInput;
        destinationDetailsSpan.innerText = destinationInput;
        dateDetailsSpan.innerText = dateInput;
        passengersDetailsSpan.innerText = passengersInput;
        priceDetailsSpan.innerText = "$" + totalAmount;

        // Display ticket details and payment options
        document.getElementById("ticket-details").style.display = "block";
        document.getElementById("payment-options").style.display = "block";
    } else {
        alert("Sorry, no price available for the selected route.");
    }
}

// Function to simulate payment and print ticket
function makePayment(paymentOption) {
    // You can add your payment logic here
    alert("Payment successful with " + paymentOption);
    buyTicket();
}

// Function to print the ticket
function printTicket() {
    var ticketDetailsDiv = document.getElementById("ticket-details");

    if (ticketDetailsDiv.style.display !== "none") {
        var printWindow = window.open('', '_blank');
        printWindow.document.write('<html><head><title>Ticket Details</title></head><body>');
        printWindow.document.write(ticketDetailsDiv.innerHTML);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.print();
    } else {
        alert("Please generate the ticket details first.");
    }
}
